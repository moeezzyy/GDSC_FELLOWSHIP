package com.example.demo_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
